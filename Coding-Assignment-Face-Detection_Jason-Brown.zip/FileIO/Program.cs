﻿using System;

namespace FileIO
{
    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Console.WriteLine("Hello World!");
    //    }
    //}

    public class FileHandler
    {
        #region Constructors
        public FileHandler() { }
        #endregion

        #region Methods
        public void DisplayFile()
        {
            Console.WriteLine("> FileHandler class check.");
        }
        #endregion
    }
}
