﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Aesthetics;

namespace DebugTools
{
    public class XDebug
    {
        Spacer sp = new Spacer();
        Header hd = new Header();

        public void ShowCheck()
        {
            hd.DisplayHeader("CHECKING SUPPORT PROJECTS");
        }
    }
}
