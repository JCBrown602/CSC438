﻿using System;

using Aesthetics;

namespace FaceDataDisplay
{
    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Console.WriteLine("Hello World!");
    //    }
    //}

    public class FaceDisplayClass
    {
        public FaceDisplayClass() { }

        public void DisplayFaceData()
        {
            Console.WriteLine("> FaceDisplayClass check.");
        }

    }
}
